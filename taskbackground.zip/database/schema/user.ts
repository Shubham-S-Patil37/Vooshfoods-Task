import mongoose, { Schema, Document } from 'mongoose';

export interface IUser extends Document {
  "_id": string,
  "name": string,
  "email": string,
  "emailVerified": boolean,
  "mobileNumber": string,
  "mobileNumberIsVerified": boolean,
  "password": string,
  "birth_date": Date;
  "gender": string,
  "address": string,
  "city": string,
  "state": string,
  "role": string
  "isActive": boolean;
}

const userSchema = new Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  emailVerified: { type: Boolean, required: false },
  mobileNumber: { type: String, required: true, unique: true },
  mobileNumberIsVerified: { type: Boolean, required: false },
  password: { type: String, required: true },
  birth_date: { type: Date, required: true },
  gender: { type: String, required: true },
  address: { type: String, required: true },
  city: { type: String, required: true },
  state: { type: String, required: true },
  role: { type: String, required: true },
  isActive: { type: Boolean, required: true },
}, {
  timestamps: true
});

const UserModel = mongoose.model<IUser>('User', userSchema);
export { UserModel }