import { Controller, Get, Post, Res, Put, Request, Body, HttpStatus, Param, Query, Response, Delete, UseGuards, Req } from '@nestjs/common';
import { UserService } from "./user.service"
import { IUser } from 'database/schema/user';
import { LoginDTO } from "./dto/login.dto"
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('user')
export class UserController {
  constructor(private userService: UserService) { }

  @UseGuards(JwtAuthGuard)
  @Get('/:skip/:limit')
  async getAllUser(@Req() req: any, @Param('skip') skip: string, @Param('limit') limit: string) {
    return await this.userService.getAllUser(skip, limit)
  }


  @UseGuards(JwtAuthGuard)
  @Get('/')
  async getUser(@Req() req: any) {
    const userId = req.user.userId
    return await this.userService.getUser(userId)
  }

  @Post('/')
  async addUser(@Body() userDetails: IUser) {
    return await this.userService.addUser(userDetails)
  }

  @UseGuards(JwtAuthGuard)
  @Put("/")
  async updateUser(@Param('id') userId: string, @Body() userDetails: IUser) {
    return await this.userService.updateUser(userId, userDetails)
  }

  @UseGuards(JwtAuthGuard)
  @Delete("/")
  async deleteUser(@Param('id') userId: string) {
    return await this.userService.deleteUser(userId)
  }

  @Post('/login')
  async login(@Body() body: LoginDTO) {
    return await this.userService.userLogin(body.email, body.password)
  }

}
